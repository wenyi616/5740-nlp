Assignment 2 starter code.
